clear;clc;close all;
% 打开文件，准备读取
fid = fopen('myreverberation.rl', 'r');
% 使用textscan读取数据
A = textscan(fid, '%s');
% 关闭文件
fclose(fid);
A=A{1};
delta=str2num(A{1});
n=str2num(A{2});
for i=3:length(A)
    if str2num(A{i})
        data(i-2)=str2num(A{i});
    else
        data(i-2)=0;
    end
end
i=1;
while(data(i)==0)
    i=i+1;
end
time=[1:length(data)]*delta;
data=data(i:end);
time=time(i:end);
figure;
time=time(1:2:end);
data=data(1:2:end);
plot(time,data,'linewidth',1);
hold on;
scatter(time(1:5:end),data(1:5:end),'Linewidth',1);
xlabel('Time (s)');
ylabel('Reverberation intensity (dB)');
legend('DPRM3','NSRM');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 10)
set(gcf,'Color',[1 1 1]);
set(gcf,'unit','centimeters','position',[10 5 16 10]);